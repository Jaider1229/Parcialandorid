package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
     EditText cantidad;
     Button comprar;
     Button Comprar;

     @SuppressLint("Missinginflatedld")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cantidad = findViewById(R.id.cantidad);
        comprar = findViewById(R.id.comprar);
        Comprar = findViewById(R.id.COMPRAR);
    }

    comprar.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){
            cantidad = Integer.parseInt(cantidad.getText().getString());

        }
    });
}